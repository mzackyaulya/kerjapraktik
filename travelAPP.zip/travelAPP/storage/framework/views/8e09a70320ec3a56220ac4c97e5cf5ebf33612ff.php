

<?php $__env->startSection('title','Rute'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="card m-4 p-3">
    <div class="card-header mb-3 d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Rute Perjalanan</h5>
        <div style="position: relative; width: 230px;">
            <input type="text" id="searchInput" class="form-control" placeholder="Cari rute..." style="height: 40px; padding-left: 35px;">
            <i class="bi bi-search" style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: #aaa;"></i>
        </div>
    </div>
     <?php if(auth()->user()->role == 'A'): ?>
        <a href="<?php echo e(route('rute.create')); ?>" class="btn btn-primary col-lg-12 mb-3">Tambah Rute</a>
     <?php endif; ?>
    <div class="card-body table-responsive d-none d-md-block">

        <table class="table table-bordered" id="ruteTable">
            <thead>
                <tr>
                    <th class="text-center">No</th>
                    <th class="text-center">Asal</th>
                    <th class="text-center">Tujuan</th>
                    <th class="text-center">Metode</th>
                    <th class="text-center">Harga</th>
                    <th class="text-center">Estimasi</th>
                    <?php if(auth()->user()->role == 'A'): ?>
                        <th class="text-center">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($index + 1); ?></td>
                        <td class="text-center"><?php echo e($item['asal']); ?></td>
                        <td class="text-center"><?php echo e($item['tujuan']); ?></td>
                        <td class="text-center"><?php echo e($item['metode']); ?></td>
                        <td class="text-center">Rp. <?php echo e(number_format($item['harga'],0,',','.')); ?></td>
                        <td class="text-center"><?php echo e($item['estimasi_waktu']); ?></td>
                        <?php if(auth()->user()->role == 'A'): ?>
                        <td class="text-center">
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item text-center" href="<?php echo e(route('rute.edit', $item['id'])); ?>"><i class="bx bx-edit-alt me-2"></i> Edit</a>
                                </div>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada rute.</td>
                    </tr>
                <?php endif; ?>
                <tr id="emptyRow" style="display: none;">
                    <td colspan="7" class="text-center">Data rute tidak ditemukan.</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="card-body d-block d-md-none" id="mobileCards">
        <?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3 shadow-sm border border-light searchable-card">
                <div class="card-body">
                    <h6 class="card-title mb-2 d-flex justify-content-between">
                        <span class="text-black fw-bold"><?php echo e($item['asal']); ?></span>
                        -
                        <span class="text-black fw-bold"><?php echo e($item['tujuan']); ?></span>
                    </h6>
                    <p class="mb-1"><strong>Metode :</strong> <?php echo e($item['metode']); ?></p>
                    <p class="mb-1"><strong>Harga :</strong> Rp. <?php echo e(number_format($item['harga'],0,',','.')); ?></p>
                    <p class="mb-1"><strong>Estimasi :</strong> <?php echo e($item['estimasi_waktu']); ?></p>

                        
                    <?php if(auth()->user()->role == 'A'): ?>
                        <div class="text-center">
                            <a href="<?php echo e(route('rute.edit', $item['id'])); ?>">
                                <i class="fas fa-pen me-2 text-gray"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if(session('success')): ?>
  <script>
    Swal.fire({
      title: "BERHASIL!",
      text: '<?php echo e(session('success')); ?>',
      icon: "success"
    });
  </script>
<?php endif; ?>


<script>
    document.getElementById('searchInput').addEventListener('keyup', function() {
        let filter = this.value.toUpperCase();
        let rows = document.querySelectorAll('#ruteTable tbody tr');
        let found = 0;

        rows.forEach(row => {
            if (row.id === 'emptyRow') return;

            let asal = row.cells[1].textContent.toUpperCase();
            let tujuan = row.cells[2].textContent.toUpperCase();
            let metode = row.cells[3].textContent.toUpperCase();
            let harga = row.cells[4].textContent.toUpperCase();
            let estimasi = row.cells[5].textContent.toUpperCase();

            if (
                asal.includes(filter) ||
                tujuan.includes(filter) ||
                metode.includes(filter) ||
                harga.includes(filter) ||
                estimasi.includes(filter)
            ) {
                row.style.display = "";
                found++;
            } else {
                row.style.display = "none";
            }
        });

        document.getElementById('emptyRow').style.display = (found === 0) ? "" : "none";
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/rute/index.blade.php ENDPATH**/ ?>