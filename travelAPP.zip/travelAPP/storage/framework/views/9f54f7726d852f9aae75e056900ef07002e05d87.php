

<?php $__env->startSection('title','Tambah Kendaraan'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="col-xl">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold">Form Tambah Kendaraan</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('kendaraan.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label" for="noplat">No Plat</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-car"></i></span>
                            <input type="text" name="noplat" id="noplat" value="<?php echo e(old('noplat')); ?>" class="form-control" placeholder="Masukan No Plat Kendaraan" required>
                        </div>
                        <?php $__errorArgs = ['noplat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="merk_mobil">Merk Kendaraan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-car"></i></span>
                            <input type="text" name="merk_mobil" id="merk_mobil" value="<?php echo e(old('merk_mobil')); ?>" class="form-control" placeholder="Masukan Merk Kendaraan" required>
                        </div>
                        <?php $__errorArgs = ['merk_mobil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="warna">Warna</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-palette"></i></span>
                            <input type="text" name="warna" id="warna" value="<?php echo e(old('warna')); ?>" class="form-control" placeholder="Masukan Warna Kendaraan" required>
                        </div>
                        <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="kapasitas">Kapasitas</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-group"></i></span>
                            <input type="number" name="kapasitas" id="kapasitas" value="<?php echo e(old('kapasitas')); ?>" class="form-control" placeholder="Masukan Kapasitas Kendaraan" required>
                        </div>
                        <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="status">Status Kendaraan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-list-check"></i></span>
                            <select name="status" id="status" class="form-control" required>
                                <option value="" disabled <?php echo e(old('status') == '' ? 'selected' : ''); ?>>Pilih Status</option>
                                <option value="Ready" <?php echo e(old('status') == 'Ready' ? 'selected' : ''); ?>>Ready</option>
                                <option value="Perbaikan" <?php echo e(old('status') == 'Perbaikan' ? 'selected' : ''); ?>>Perbaikan</option>
                            </select>
                        </div>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group text-right mt-3">
                        <button type="submit" class="btn btn-success">Simpan</button>
                        <a href="<?php echo e(url('kendaraan')); ?>" class="btn btn-transparant">Cancel</a>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/kendaraan/create.blade.php ENDPATH**/ ?>