

<?php $__env->startSection('title','Tambah Rute'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="col-xl">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold">Form Tambah Rute</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('rute.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="form-label" for="asal">Asal Perjalanan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-map"></i></span>
                            <input type="text" name="asal" id="asal" value="<?php echo e(old('asal')); ?>" class="form-control" placeholder="Masukan Asal Perjalanan" required>
                        </div>
                        <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="tujuan">Tujuan Perjalanan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-map-pin"></i></span>
                            <input type="text" name="tujuan" id="tujuan" value="<?php echo e(old('tujuan')); ?>" class="form-control" placeholder="Masukan Tujuan Perjalanan" required>
                        </div>
                        <?php $__errorArgs = ['tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="metode">Metode Perjalanan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-transfer"></i></span>
                            <select name="metode" id="metode" class="form-control" required>
                                <option value="" disabled <?php echo e(old('metode') == '' ? 'selected' : ''); ?>>Pilih Metode Perjalanan</option>
                                <option value="SHUTTLE" <?php echo e(old('metode') == 'SHUTTLE' ? 'selected' : ''); ?>>SHUTTLE</option>
                                <option value="REGULAR" <?php echo e(old('metode') == 'REGULAR' ? 'selected' : ''); ?>>REGULAR</option>
                                <option value="SEMI-SHUTTLE" <?php echo e(old('metode') == 'SEMI-SHUTTLE' ? 'selected' : ''); ?>>SEMI-SHUTTLE</option>
                            </select>
                        </div>
                        <?php $__errorArgs = ['metode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="harga">Harga Perjalanan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-money"></i></span>
                            <input type="number" name="harga" id="harga" value="<?php echo e(old('harga')); ?>" class="form-control" placeholder="Masukan Harga" required>
                        </div>
                        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="estimasi_waktu">Estimasi Perjalanan</label>
                        <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="bx bx-time-five"></i></span>
                        <input type="text" name="estimasi_waktu" id="estimasi_waktu" value="<?php echo e(old('estimasi_waktu')); ?>" class="form-control" placeholder="Masukan Estimasi Waktu" required>
                        </div>
                        <?php $__errorArgs = ['estimasi_waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group text-right mt-3">
                        <button type="submit" class="btn btn-success">Simpan</button>
                        <a href="<?php echo e(url('rute')); ?>" class="btn btn-transparant">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/rute/create.blade.php ENDPATH**/ ?>