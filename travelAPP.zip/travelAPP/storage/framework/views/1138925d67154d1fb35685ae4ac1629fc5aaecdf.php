

<?php $__env->startSection('title','Edit Kendaraan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="card p-4 shadow" style="max-width: 600px; width: 100%;">
        <div class="card-header mb-3">
            <h5 class="card-title mb-0">Form Edit Kendaraan</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('kendaraan.update', $kendaraan['id'])); ?>" class="forms-sample" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="noplat">No Plat</label>
                <input type="text" class="form-control" id="noplat" name="noplat" value="<?php echo e(old('noplat') ? old('noplat'): $kendaraan['noplat']); ?>">
                <?php $__errorArgs = ['noplat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="merk_mobil">Merk Kendaraan</label>
                <input type="text" class="form-control" id="merk_mobil" name="merk_mobil" value="<?php echo e(old('merk_mobil') ? old('merk_mobil'): $kendaraan['merk_mobil']); ?>">
                <?php $__errorArgs = ['merk_mobil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="warna">Warna</label>
                <input type="text" class="form-control" id="warna" name="warna" value="<?php echo e(old('warna') ? old('warna'): $kendaraan['warna']); ?>">
                <?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="kapasitas">Kapasitas</label>
                <input type="text" class="form-control" id="kapasitas" name="kapasitas" value="<?php echo e(old('kapasitas') ? old('kapasitas'): $kendaraan['kapasitas']); ?>">
                <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control" id="status" name="status">
                    <option value="Ready" <?php echo e(old('status', $kendaraan['status']) == 'Ready' ? 'selected' : ''); ?>>Ready</option>
                    <option value="Perbaikan" <?php echo e(old('status', $kendaraan['status']) == 'Perbaikan' ? 'selected' : ''); ?>>Perbaikan</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group text-right mt-3">
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(url('kendaraan')); ?>" class="btn btn-transparant">Batal</a>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/kendaraan/edit.blade.php ENDPATH**/ ?>