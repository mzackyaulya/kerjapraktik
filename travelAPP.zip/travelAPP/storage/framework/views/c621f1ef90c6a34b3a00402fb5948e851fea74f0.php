<?php $__env->startSection('title','Pemesanan'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="card p-2">
    <div class="card-header mb-3 d-flex justify-content-between align-items-center flex-wrap">
        <h5 class="card-title mb-0">Pemesanan Tiket</h5>
        <div class="mt-2 position-relative" style="width: 230px;">
            <input type="text" id="searchInput" class="form-control ps-4" placeholder="Pencarian...">
            <i class="fas fa-search position-absolute" style="left: 7px; top: 50%; transform: translateY(-50%); color: #aaa;"></i>
        </div>
    </div>

    
    <div class="card-body table-responsive d-none d-md-block">
        <table class="table table-bordered table-hover align-middle text-center" id="ruteTable">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>No HP</th>
                    <th>No Kursi</th>
                    <th>Jumlah</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Status</th>
                    <th>Info</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="searchable-row">
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item['nama_pemesan']); ?></td>
                    <td><?php echo e($item['nohp']); ?></td>
                    <td><?php echo e($item['daftar_kursi'] ?? $item['seet']); ?></td>
                    <td><?php echo e($item['jumlah_orang'] ?? '-'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item['tanggal_pesan'] ?? $item['jadwal']['tanggal'])->format('d-m-Y')); ?></td>
                    <td><?php echo e($item['jadwal']['jam'] ?? '-'); ?></td>
                    <td>
                        <span class="badge
                            <?php echo e($item['status'] === 'Pending' ? 'bg-warning text-dark' :
                               ($item['status'] === 'Dikonfirmasi' ? 'bg-success' : 'bg-secondary')); ?>">
                            <?php echo e($item['status']); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('pesan.show', ['pesan' => $item['id']])); ?>" class="btn btn-sm btn-secondary">
                            <i class="fas fa-eye"></i>
                        </a>
                    </td>
                    <td class="text-center" style="position: relative">
                        <div class="dropdown">
                            <button class="btn btn-sm btn-transparant" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                <li>
                                    <a href="<?php echo e(route('pesan.edit', ['pesan' => $item['id']])); ?>" class="dropdown-item">
                                        <i class="fas fa-pen me-2 text-info"></i> Edit
                                    </a>
                                </li>
                                <?php if(auth()->user()->role == 'A'): ?>
                                    <li>
                                        <a href="<?php echo e(route('pesan.cetak', ['id' => $item['id']])); ?>" target="_blank" class="dropdown-item">
                                            <i class="fas fa-print me-2 text-dark"></i> Cetak
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(auth()->user()->role == 'A'): ?>
                                    <?php if($item['status'] !== 'Dikonfirmasi'): ?>
                                        <li>
                                            <form action="<?php echo e(route('pesan.konfirmasi', ['id' => $item['id']])); ?>" method="POST" onsubmit="return confirm('Konfirmasi pemesanan ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button class="dropdown-item" type="submit">
                                                    <i class="fas fa-check-circle me-2 text-success"></i> Dikonfirmasi
                                                </button>
                                            </form>
                                        </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if($item['status'] !== 'Batal'): ?>
                                <li>
                                    <form action="<?php echo e(route('pesan.batal', ['id' => $item['id']])); ?>" method="POST" onsubmit="return confirm('Batalkan pemesanan ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button class="dropdown-item" type="submit">
                                            <i class="fas fa-times-circle me-2 text-danger"></i> Batal
                                        </button>
                                    </form>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div class="card-body d-block d-md-none" id="mobileCards">
        <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3 shadow-sm border border-light searchable-card">
                <div class="card-body">
                    <h5 class="card-title mb-2 d-flex justify-content-between">
                        <span class="text-black fw-bold"><?php echo e($item['nama_pemesan']); ?></span>
                        <span class="badge
                            <?php echo e($item['status'] === 'Pending' ? 'bg-warning text-dark' :
                            ($item['status'] === 'Dikonfirmasi' ? 'bg-success' : 'bg-secondary')); ?>">
                            <?php echo e($item['status']); ?>

                        </span>
                    </h5>
                    <p class="mb-1"><strong>No HP:</strong> <?php echo e($item['nohp']); ?></p>
                    <p class="mb-1"><strong>Kursi:</strong> <?php echo e($item['daftar_kursi'] ?? $item['seet']); ?></p>
                    <p class="mb-1"><strong>Jumlah:</strong> <?php echo e($item['jumlah_orang'] ?? '-'); ?></p>
                    <p class="mb-1"><strong>Tanggal:</strong> <?php echo e(\Carbon\Carbon::parse($item['tanggal_pesan'] ?? $item['jadwal']['tanggal'])->format('d-m-Y')); ?></p>
                    <p class="mb-1"><strong>Jam:</strong> <?php echo e($item['jadwal']['jam'] ?? '-'); ?></p>

                    <div class="d-flex justify-content-start flex-wrap gap-2 mt-3">
                        
                        <a href="<?php echo e(route('pesan.show', ['pesan' => $item['id']])); ?>" class="btn btn-sm btn-secondary" title="Lihat">
                            <i class="fas fa-eye"></i>
                        </a>

                        
                        <a href="<?php echo e(route('pesan.edit', ['pesan' => $item['id']])); ?>" class="btn btn-sm btn-info" title="Edit">
                            <i class="fas fa-pen"></i>
                        </a>

                        
                        <?php if(auth()->user()->role == 'A'): ?>
                            <a href="<?php echo e(route('pesan.cetak', ['id' => $item['id']])); ?>" target="_blank" class="btn btn-sm btn-dark" title="Cetak">
                                <i class="fas fa-print"></i>
                            </a>
                        <?php endif; ?>

                        
                        <?php if(auth()->user()->role == 'A' && $item['status'] !== 'Dikonfirmasi'): ?>
                            <form action="<?php echo e(route('pesan.konfirmasi', $item['id'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="bg-gray">
                                    <i class="fas fa-check-circle text-success"></i>
                                </button>
                            </form>
                        <?php endif; ?>

                        
                        <?php if(in_array(auth()->user()->role, ['A','U']) && $item['status'] !== 'Batal'): ?>
                            <form action="<?php echo e(route('pesan.batal', ['id' => $item['id']])); ?>" method="POST" onsubmit="return confirm('Batalkan pemesanan ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" title="Batal">
                                    <i class="fas fa-times-circle"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Audio untuk notifikasi -->
<audio id="notif-audio" src="<?php echo e(asset('notif.mp3')); ?>" preload="auto"></audio>


<script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Realtime search filtering
    $('#searchInput').on('keyup', function () {
        let keyword = $(this).val().toLowerCase();

        $('.searchable-row').each(function () {
            let text = $(this).text().toLowerCase();
            $(this).toggle(text.includes(keyword));
        });

        $('.searchable-card').each(function () {
            let text = $(this).text().toLowerCase();
            $(this).toggle(text.includes(keyword));
        });
    });
</script>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: "BERHASIL!",
        text: '<?php echo e(session('success')); ?>',
        icon: "success"
    });
</script>
<?php endif; ?>


<script>
    const inputJumlahOrang = document.querySelector('#jumlah_orang');
    const checkboxKursi = document.querySelectorAll('.kotak-kursi');
    const infoKursi = document.getElementById('info-kursi-terpilih');

    function perbaruiKursi() {
        const jumlahMaks = parseInt(inputJumlahOrang.value) || 0;
        const kursiDipilih = [...checkboxKursi].filter(cb => cb.checked);

        // Reset semua checkbox jika jumlah kosong atau 0
        if (!jumlahMaks || jumlahMaks <= 0) {
            checkboxKursi.forEach(cb => {
                cb.checked = false;
                cb.disabled = true;
            });
            infoKursi.textContent = 'Masukkan jumlah orang untuk mengaktifkan pilihan kursi.';
            infoKursi.className = 'text-muted mt-1 d-block';
            return;
        }

        // Aktifkan semua kursi, lalu batasi sesuai jumlah orang
        checkboxKursi.forEach(cb => {
            cb.disabled = kursiDipilih.length >= jumlahMaks && !cb.checked;
        });

        infoKursi.textContent = `Kursi dipilih: ${kursiDipilih.length} dari ${jumlahMaks}`;
        infoKursi.className = kursiDipilih.length > jumlahMaks ? 'text-danger mt-1 d-block' : 'text-primary mt-1 d-block';
    }

    inputJumlahOrang.addEventListener('input', () => {
        checkboxKursi.forEach(cb => {
            cb.checked = false;
        cb.disabled = false;
        });
        perbaruiKursi();
    });

    checkboxKursi.forEach(cb => cb.addEventListener('change', perbaruiKursi));
    perbaruiKursi();
</script>


<script src="https://js.pusher.com/7.2/pusher.min.js"></script>
<script>
    Pusher.logToConsole = false;

    const pusher = new Pusher('<?php echo e(env('VITE_PUSHER_APP_KEY')); ?>', {
        cluster: '<?php echo e(env('VITE_PUSHER_APP_CLUSTER')); ?>',
        forceTLS: true
    });

    const channel = pusher.subscribe('pemesanan-channel');

    channel.bind('pemesanan-masuk', function(data) {
        const audio = document.getElementById('notif-audio');
        if (audio) audio.play();
        
        Swal.fire({
            title: 'Pemesanan Baru!',
            text: 'Pesanan dari: ' + data.nama,
            icon: 'info',
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 5000
        });

        // opsional: reload data
        setTimeout(() => {
            location.reload();
        }, 2000);
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/pesan/index.blade.php ENDPATH**/ ?>