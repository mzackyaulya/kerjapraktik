

<?php $__env->startSection('title','Edit Data User'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row">
  <div class="col-xl">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0 fw-bold">Form Edit Data User</h5>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('pelanggan.update', $pelanggan['id'])); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="mb-3">
            <label class="form-label" for="basic-default-fullname">Nama Lengkap</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="bx bx-user"></i></span>
              <input type="text" name="name" id="name" value="<?php echo e($pelanggan['name']); ?>" class="form-control" placeholder="Masukan Nama Lengkap" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="basic-default-email">Email</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="bx bx-envelope"></i></span>
              <input type="email" name="email" value="<?php echo e($pelanggan['email']); ?>" class="form-control" placeholder="Email" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="basic-default-alamat">Alamat</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="bx bx-home"></i></span>
              <input type="text" name="alamat" value="<?php echo e($pelanggan->alamat); ?>" class="form-control" placeholder="Alamat" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="basic-default-phone">No HP</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="bx bx-phone"></i></span>
              <input type="text" name="nohp" value="<?php echo e($pelanggan->nohp); ?>" class="form-control phone-mask" placeholder="08xxxxxxxxxx" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="basic-default-foto">Foto</label>
            <input type="file" name="foto" class="form-control">
            <?php if($pelanggan->foto): ?>
              <small class="text-muted">Foto sekarang:</small><br>
              <img src="<?php echo e(asset('foto/pelanggan/' . $pelanggan->foto)); ?>" alt="Foto" width="100" class="mt-2">
            <?php endif; ?>
          </div>

          <button type="submit" class="btn btn-primary">Update</button>
          <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-transparant">Cancel</a>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/pelanggan/edit.blade.php ENDPATH**/ ?>