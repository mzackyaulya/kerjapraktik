

<?php $__env->startSection('title', 'Tambah Pemesanan'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="card m-4 p-3">
    <div class="card-header mb-3">
        <h5 class="card-title mb-0">Form Tambah Pemesanan Tiket</h5>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('pesan.store', $selectedJadwal ? $selectedJadwal->id : '')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- Pilih Jadwal -->
            <div class="mb-3">
                <label for="jadwal_id" class="form-label">Pilih Jadwal</label>
                <select name="jadwal_id" id="jadwal_id" class="form-control" required>
                    <option value="">-- Pilih Jadwal --</option>
                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataJadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dataJadwal->id); ?>"
                            <?php echo e(isset($selectedJadwal) && $selectedJadwal->id == $dataJadwal->id ? 'selected' : ''); ?>>
                            <?php echo e($dataJadwal->rute['asal']); ?> ke <?php echo e($dataJadwal->rute['tujuan']); ?> | <?php echo e($dataJadwal->tanggal); ?> <?php echo e($dataJadwal->jam); ?> | Metode: <?php echo e($dataJadwal->rute['metode']); ?> | Harga: Rp. <?php echo e(number_format($dataJadwal->rute['harga'], 0, ',', '.')); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['jadwal_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Nama Pemesan -->
            <div class="mb-3">
                <label for="nama_pemesan" class="form-label">Nama Pemesan</label>
                <input type="text" name="nama_pemesan" class="form-control" value="<?php echo e(old('nama_pemesan')); ?>" required>
                <?php $__errorArgs = ['nama_pemesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Nomor HP -->
            <div class="mb-3">
                <label for="nohp" class="form-label">Nomor HP</label>
                <input type="text" name="nohp" class="form-control" value="<?php echo e(old('nohp')); ?>" required>
                <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Alamat -->
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat')); ?>" required>
                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Jumlah Orang -->
            <div class="mb-3">
                <label for="jumlah_orang" class="form-label">Jumlah Orang</label>
                <input type="number" name="jumlah_orang" id="jumlah_orang" class="form-control" value="<?php echo e(old('jumlah_orang')); ?>" min="1" required>
                <?php $__errorArgs = ['jumlah_orang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Pilih Kursi -->
            <div class="mb-3">
                <label class="form-label">Pilih Kursi (Sesuai Jumlah Orang)</label>
                <div class="row row-cols-4 g-2">
                    <?php $__currentLoopData = $kursiTersedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kursi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="form-check">
                                <input class="form-check-input kotak-kursi" type="checkbox" name="seet[]" value="<?php echo e($kursi); ?>" id="kursi<?php echo e($kursi); ?>" disabled>
                                <label class="form-check-label" for="kursi<?php echo e($kursi); ?>">
                                    <?php echo e($kursi); ?>

                                </label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <small id="info-kursi-terpilih" class="text-muted mt-2 d-block">Masukkan jumlah orang untuk mengaktifkan pilihan kursi.</small>
                <?php $__errorArgs = ['seet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Tombol -->
            <button type="submit" class="btn btn-primary col-12">Pesan</button>
            <a href="<?php echo e(route('pesan.index')); ?>" class="btn btn-secondary col-12 mt-2">Kembali</a>
        </form>
    </div>
</div>

<!-- Script Validasi Kursi -->
<script>
    const inputJumlahOrang = document.querySelector('#jumlah_orang');
    const checkboxKursi = document.querySelectorAll('.kotak-kursi');
    const infoKursi = document.getElementById('info-kursi-terpilih');

    function perbaruiKursi() {
        const jumlahMaks = parseInt(inputJumlahOrang.value) || 0;
        const kursiDipilih = [...checkboxKursi].filter(cb => cb.checked);

        if (!jumlahMaks || jumlahMaks <= 0) {
            checkboxKursi.forEach(cb => {
                cb.checked = false;
                cb.disabled = true;
            });
            infoKursi.textContent = 'Masukkan jumlah orang untuk mengaktifkan pilihan kursi.';
            infoKursi.className = 'text-muted mt-1 d-block';
            return;
        }

        // Aktifkan semua checkbox
        checkboxKursi.forEach(cb => cb.disabled = false);

        // Batasi jika sudah maksimal
        if (kursiDipilih.length >= jumlahMaks) {
            checkboxKursi.forEach(cb => {
                if (!cb.checked) cb.disabled = true;
            });
        } else {
            checkboxKursi.forEach(cb => cb.disabled = false);
        }

        infoKursi.textContent = `Kursi dipilih: ${kursiDipilih.length} dari ${jumlahMaks}`;
        infoKursi.className = kursiDipilih.length > jumlahMaks ? 'text-danger mt-1 d-block' : 'text-primary mt-1 d-block';
    }

    inputJumlahOrang.addEventListener('input', perbaruiKursi);
    checkboxKursi.forEach(cb => cb.addEventListener('change', perbaruiKursi));
    perbaruiKursi(); // panggil saat awal
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/pesan/create.blade.php ENDPATH**/ ?>