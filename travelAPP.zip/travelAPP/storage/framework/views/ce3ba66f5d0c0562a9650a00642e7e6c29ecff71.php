<?php $__env->startSection('title','Tambah Jadwal'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="col-xl">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold">Form Tambah Jadwal</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('jadwal.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label" for="rute_id">Rute</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-map"></i></span>
                            <select class="form-control" name="rute_id" id="rute_id">
                                <option value="">Pilih Rute</option>
                                <?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($items['id']); ?>" <?php echo e(old('rute_id') == $items['id'] ? 'selected' : ''); ?>>
                                        <?php echo e($items['asal']); ?> - <?php echo e($items['tujuan']); ?> - <?php echo e($items['metode']); ?> - <?php echo e($items['harga']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php $__errorArgs = ['rute_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="kendaraan_id">Kendaraan</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-car"></i></span>
                            <select class="form-control" name="kendaraan_id" id="kendaraan_id">
                                <option value="">Pilih Kendaraan</option>
                                <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($items['id']); ?>" <?php echo e(old('kendaraan_id') == $items['id'] ? 'selected' : ''); ?>>
                                        <?php echo e($items['noplat']); ?> - <?php echo e($items['merk_mobil']); ?> - <?php echo e($items['warna']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php $__errorArgs = ['kendaraan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="sopir_id">Sopir</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-user-pin"></i></span>
                            <select class="form-control" name="sopir_id" id="sopir_id">
                                <option value="">Pilih Sopir</option>
                                <?php $__currentLoopData = $sopir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($items['id']); ?>" <?php echo e(old('sopir_id') == $items['id'] ? 'selected' : ''); ?>>
                                        <?php echo e($items['nama']); ?> - <?php echo e($items['nohp']); ?> - <?php echo e($items['status']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php $__errorArgs = ['sopir_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="tanggal">Tanggal Jadwal</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-calendar"></i></span>
                            <input type="date" name="tanggal" id="tanggal" value="<?php echo e(old('tanggal')); ?>" class="form-control" required>
                        </div>
                        <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="jam">Jam Jadwal</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="bx bx-time"></i></span>
                            <input type="time" name="jam" id="jam" value="<?php echo e(old('jam')); ?>" class="form-control" required>
                        </div>
                        <?php $__errorArgs = ['jam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group text-right mt-3">
                        <button type="submit" class="btn btn-success">Simpan</button>
                        <a href="<?php echo e(url('jadwal')); ?>" class="btn btn-transparant">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kp\kerjapraktik\travelAPP\resources\views/jadwal/create.blade.php ENDPATH**/ ?>